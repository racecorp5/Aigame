# SYSTEM BREACH — Animation Sprite Sheet Pack

This pack adds multi-frame sprite-sheet animations to the Clean Neon Systems asset pack.

Included:
- Agent idle bounce/sway sheets: 7
- Enemy corrupt sway sheets: 19
- Weapon gleam sheets: 4
- Armor gleam sheets: 4
- Item pulse sheets: 4
- Currency pulse sheets: 2
- Combat VFX sheets: 6
- UI VFX sheets: 3
- Preview GIFs for quick review
- animation_manifest.json

All sheets are horizontal strips.
Use frameWidth/frameHeight/frames/fps from animation_manifest.json.

Suggested animation set:
- Agents: idle_bounce_sway, attack wind-up later, hit reaction later, downed later
- Enemies: idle_corrupt_sway, attack charge later, death glitch later
- Gear: gleam loop in shop/equipment screen
- Items/currency: pulse loop when available or newly earned
- Effects: use combat and UI VFX sheets directly
